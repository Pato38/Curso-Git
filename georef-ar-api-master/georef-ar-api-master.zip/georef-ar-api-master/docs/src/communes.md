# Comunas de CABA
Las comunas de la Ciudad Autónoma de Buenos Aires (CABA) se encuentran disponibles bajo el recurso `/departamentos`. Los IDs y los nombres de las comunas están definidos por la [Resolución 55/2019 de INDEC](https://www.boletinoficial.gob.ar/detalleAviso/primera/203487/20190318), y son los siguientes:

<table>
    <tr><th>ID</th><th>Nombre Oficial</th></tr>
	<tr><td>02007</td><td>Comuna 1 </td></tr>
	<tr><td>02014</td><td>Comuna 2 </td></tr>
	<tr><td>02021</td><td>Comuna 3 </td></tr>
	<tr><td>02028</td><td>Comuna 4 </td></tr>
	<tr><td>02035</td><td>Comuna 5 </td></tr>
	<tr><td>02042</td><td>Comuna 6 </td></tr>
	<tr><td>02049</td><td>Comuna 7 </td></tr>
	<tr><td>02056</td><td>Comuna 8 </td></tr>
	<tr><td>02063</td><td>Comuna 9 </td></tr>
	<tr><td>02070</td><td>Comuna 10</td></tr>
	<tr><td>02077</td><td>Comuna 11</td></tr>
	<tr><td>02084</td><td>Comuna 12</td></tr>
	<tr><td>02091</td><td>Comuna 13</td></tr>
	<tr><td>02098</td><td>Comuna 14</td></tr>
	<tr><td>02105</td><td>Comuna 15</td></tr>
</table>
