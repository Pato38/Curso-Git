var icon = (Document.getElementsByClassName().style.opacity = 0)
console.log(icon)
